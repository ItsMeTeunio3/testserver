# Wet- en Regelgeving Tedeapolis

Welkom op de pagina voor de Wet- en Regelgeving van Tedeapolis!
In het menu aan de linkerkant vind je alle verschillende documenten die betrekking hebben op Tedeapolis.

Zorg ervoor, dat je voor je deelneemt aan Tedeapolis, kennis hebt genomen van deze wetten.

- De Algemene Plaatselijke Verordening bevat alle regels die niet te maken hebben met de Roleplay (dit zijn zogezegd de "server regels").
- Het Wetboek Tedeapolis bevat alle wetten voor de burgers.
- Alle overige documenten zijn specifiek bedoeld voor bepaalde zaken (zoals een belastingdocument waar je kan opzoeken hoeveel de autobelasting is).

## Officiële discord servers

Tedeapolis heeft verschillende discord servers die zijn goed gekeurd door het stadsbestuur deze zijn:

| Server | Beschrijving | Invite link |
|---|---|:---:|
|Tedeapolis RolePlay| Main discord server van Tedeapolis | [Invite](https://discord.gg/tedeapolis) |
|Tedeapolis Support| Support discord server van Tedeapolis | [Invite](https://discord.gg/uQ9jGA93yC) |
|Tedeapolis Cardealer| Cardealer discord server van Tedeapolis | [Invite](https://discord.gg/UcCG2kn) |
|Tedeapolis Flightschool| Vliegschool discord server van Tedeapolis | [Invite](https://discord.gg/JMrvTrZqcz) |
|Ministerie van Justitie en Veiligheid| Ministerie van Justitie en Veiligheid van Tedeapolis | [Invite](https://discord.gg/KPTt4ce5nw) |

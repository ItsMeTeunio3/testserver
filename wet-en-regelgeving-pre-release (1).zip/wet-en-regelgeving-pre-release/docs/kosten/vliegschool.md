# Vliegschool

De Vliegschool hanteert de volgende prijzen voor de verschillende opleidingen en brevetten die zij leveren.

| Type | Prijs |
|---|---|
|Helikopter of propeller| € 150000,-|
|extra aantekening Helikopter of propeller | € 75000,-|
|Aantekening jets | € 75000,- |
|Aantekening stuntvliegen | € 25000,- |

!!! attention "LET OP"
    De prijzen kunnen ten alle tijden worden worden gewijzigd

# Wet en regelgeving Tedeapolis

## Development

### local mkdocs server

Om Mkdocs lokaal te runnen kan je binnen WSL2 er voor kiezen om een venv te maken met alle tools er in. Dit doe je doormiddel van de volgende commando's

```
./create-venv-unix.sh
source .venv/bin/activate
```

`git fetch origin pull/$ID/head:$BRANCHNAME`


## format release

```md

**Aanpassingen Week X**

**APV**

* Geen aanpassingen

**Wetboek**

* Geen aanpassingen

**Overig**

* Geen aanpassingen

```